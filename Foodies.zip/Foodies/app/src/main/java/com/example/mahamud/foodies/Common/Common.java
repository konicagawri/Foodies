package com.example.mahamud.foodies.Common;

import com.example.mahamud.foodies.Model.User;

public class Common {
    public  static User currentUser;
}
