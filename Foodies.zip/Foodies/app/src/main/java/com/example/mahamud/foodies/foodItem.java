package com.example.mahamud.foodies;

import android.app.Activity;

public class foodItem extends Activity {
}
